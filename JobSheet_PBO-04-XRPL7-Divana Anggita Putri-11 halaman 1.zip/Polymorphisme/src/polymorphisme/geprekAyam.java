
package polymorphisme;

/**
 *
 * @author ASUS
 */
public class geprekAyam extends makanan{
    void rasa(){
        System.out.println("pedas, asin");
    } 
    void tekstur(){
        System.out.println("keras");
    }
    void harga(){
        System.out.println("terjangkau");
    }
}
