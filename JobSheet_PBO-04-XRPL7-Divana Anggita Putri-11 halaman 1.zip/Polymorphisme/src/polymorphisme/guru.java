package polymorphisme;

public class guru extends manusia{
    void makan(){
        System.out.println("guru makan");
    }
    void tidur(){
        System.out.println("guru tidur");
    }
    void bergerak (){
        System.out.println("guru bergerak");
    }
}
