package polymorphisme;

public class manusia {
    void makan (){
        System.out.println("Manusia Makan");
    }
    void tidur () {
        System.out.println("Manusia Tidur");
    }
    void bergerak(){
        System.out.println("Manusia Bergerak");
    }
}
