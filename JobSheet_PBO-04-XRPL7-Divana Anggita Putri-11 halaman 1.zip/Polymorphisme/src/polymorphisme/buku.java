package polymorphisme;

/**
 *
 * @author divana
 */
public interface buku{
        public void cover();
        public void judul();
        public void bab();
    }
