package polymorphisme;

public class karyawan extends manusia{
    void makan(){
        System.out.println("karyawan makan");
    }
    void tidur(){
        System.out.println("karyawan tidur");
    }
    void bergerak(){
        System.out.println("karyawan bergerak");
    }
}
