
package polymorphisme;

/**
 *
 * @author DIVANA
 */
public class buburAyam extends makanan{

    void rasa(){
        System.out.println("ASIN, PEDAS");
    }
    void tekstur(){
        System.out.println("LENGKET, CAIR");
    }
    void harga(){
        System.out.println(" terjangkau ");
    }
}
