package polymorphisme;

public class siswa extends manusia {
    
    void makan (){
        System.out.println("Siswa Makan");
    }
    void tidur (){
        System.out.println("Siswa Tidur");
    }
    void bergerak (){
        System.out.println("Siswa Bergerak");
    }
}
