package polymorphisme;

/**
 *
 * @author DIVANA
 */
public class makanan {

    void rasa(){
        System.out.println("ASIN, ASAM, MANIS, PEDAS, PAHIT");
    }
    void tekstur(){
        System.out.println("LEMBUT, KERAS, ALOT, CAIR");
    }
    void harga(){
        System.out.println("TERGANGKAU, MAHAL");
    }
}
