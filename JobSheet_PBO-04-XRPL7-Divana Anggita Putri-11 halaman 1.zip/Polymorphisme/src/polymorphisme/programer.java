package polymorphisme;

public class programer extends manusia{
    void makan (){
        System.out.println("programer makan");
    }
    void tidur (){
        System.out.println("programer tidur");
    }
    void bergerak(){
        System.out.println("programer bergerak");
    }
}
