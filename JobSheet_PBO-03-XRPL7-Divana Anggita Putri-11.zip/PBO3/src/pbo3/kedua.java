package pbo3;

/**
 *
 * @author ASUS
 */
class kedua extends pertama{
    private int b = 8;
    
    protected void BacaSuper () {
        System.out.println("Nilai b : " +b);
        terprotek();
        info ();
    }
}
