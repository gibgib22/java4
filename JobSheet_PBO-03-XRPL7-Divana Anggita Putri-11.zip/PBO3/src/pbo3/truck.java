package pbo3;

/**
 *
 * @author ASUS
 */
public class truck {
    public int cadence;
    public int gear;
    public int speed;
    
    public truck (int startCadence, int startSpeed, int startGear){
    gear = startGear;
    cadence = startCadence;
    speed = startSpeed;
    }
    public void setCadence (int newValue){
    cadence = newValue;
    }
    public void setGear (int newValue){
    gear = newValue;
    }
    public void Applybrake (int decrement){
    speed = decrement;
    }
    public void speedUp (int increment){
    speed = increment;
    }
}
