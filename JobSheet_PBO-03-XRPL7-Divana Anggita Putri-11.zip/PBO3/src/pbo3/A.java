package pbo3;

/**
 *
 * @author ASUS
 */
public class A {
    private int a;
    public void setA (int nilai)
    {
    a = nilai;
    }
    public int getA()
    {
    return a;
    }
    
    public void tampilkanNilai (){
        System.out.println(" Nilai a : " + getA());
    }
}
