package pbo3;

/**
 *
 * @author ASUS
 */
public class testpertamakedua {
    public static void main (String[]args){
    kedua D2 = new kedua ();
    D2.BacaSuper ();
    D2.info();
    
    pertama S1 = new pertama();
    S1.terprotek();
    S1.info();
    }
}
