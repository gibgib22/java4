package pbo3;

/**
 *
 * @author ASUS
 */
public class mainprojek {
    public static void main (String [] args){
    tugasPraktikum a = new tugasPraktikum ();
    a.organisasi();
    }
}
