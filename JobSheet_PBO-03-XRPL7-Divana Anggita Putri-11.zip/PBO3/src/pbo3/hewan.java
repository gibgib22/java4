package pbo3;

public class hewan {
    public static void teatClassMethod(){
        System.out.println("The Class Method in Hewan.....");
    }
    
    public void testIntanceMethod(){
        System.out.println("The intance Method in Hewan...");
    }
}
