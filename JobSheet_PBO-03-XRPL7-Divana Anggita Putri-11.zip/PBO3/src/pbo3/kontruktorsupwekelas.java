
package pbo3;

/**
 *
 * @author ASUS
 */
public class kontruktorsupwekelas {
    public static void main (String[]args){
    employ programer1 = new employ ("12345678","yanto", 32);
    programer1.info();
    }
}
