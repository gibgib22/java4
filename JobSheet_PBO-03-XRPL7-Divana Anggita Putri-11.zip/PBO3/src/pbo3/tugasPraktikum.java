package pbo3;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class tugasPraktikum {
    private String ekstra;
    private String scan;
    
    public void organisasi(){
        Scanner input = new Scanner (System.in);
        String jawab = null;
        
        do{
        System.out.println("----------------------");
        System.out.println("   Pilih Organisasi   ");
        System.out.println("1. OSIS ");
        System.out.println("2. PMR  ");
        System.out.println("3. DA   ");
        System.out.println("Tentukan pilihan anda:");
        scan = input.nextLine();
        
        if (scan.equals("1.")||scan.equals("1")||scan.equals("osis")){
            System.out.println("-----------------||-----------------");
            System.out.println("Senang Bergabung Di OSIS");
            System.out.println("SEMOGA MENYENANGKAN");
            System.out.println("JADILAH BERTANGGUNG JAWAB");
            System.out.println("Terimakasih");
            System.out.println("");
            System.out.println("");
            System.out.println(" APAKAH ANDA INGIN BERGABUNG KE ORGANISASI YANG LAINNYA ");
            jawab = input.nextLine();
        } else if (scan.equals("2.")||scan.equals("2")||scan.equals("PMR")){
            System.out.println("-----------------||-----------------");
            System.out.println("Senang Bergabung Di PMR");
            System.out.println("SEMOGA MENYENANGKAN");
            System.out.println("JADILAH BERTANGGUNG JAWAB");
            System.out.println("Terimakasih");
            System.out.println("");
            System.out.println("");
            System.out.println(" APAKAH ANDA INGIN BERGABUNG KE ORGANISASI YANG LAINNYA ");
            jawab = input.nextLine();
        } else {
            System.out.println("-----------------||-----------------");
            System.out.println("Senang Bergabung Di DA");
            System.out.println("SEMOGA MENYENANGKAN");
            System.out.println("JADILAH BERTANGGUNG JAWAB");
            System.out.println("Terimakasih");
            System.out.println("");
            System.out.println("");
            System.out.println(" APAKAH ANDA INGIN BERGABUNG KE ORGANISASI YANG LAINNYA ");
            jawab = input.nextLine();
        }
        } while (jawab.equals("ya")||jawab.equals("y")||jawab.equals("YA"));
            System.out.println("");
            System.out.println("BAIKLAH");
    }
}
