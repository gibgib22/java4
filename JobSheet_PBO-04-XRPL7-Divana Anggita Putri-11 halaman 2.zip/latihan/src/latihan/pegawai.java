
package latihan;

public class pegawai {
    String nama;
    int gaji;
    pegawai(){
    }
    pegawai(String nm){
        this.nama=nm;
        System.out.println("pegawai");
    }
    public int gaji(){
        return 0;
    }
}
