
package latihan;

public abstract class vehicle {

    public void function(){
        System.out.println("Transportation tools");
    }
    public void fuel(){
        System.out.println("Fuels");
    }
    public abstract void walk ();
}