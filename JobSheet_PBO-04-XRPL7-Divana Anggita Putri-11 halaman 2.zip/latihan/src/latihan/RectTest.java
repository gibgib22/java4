package latihan;

/**
 *
 * @author DIVANA
 */
public class RectTest extends rect{
    public static void main(String[] args) {
        rect i = new rect();
        i.x1=2;
        i.x2=3;
        i.y1=4;
        i.y2=2;
        
        i.move(0, 0);
        i.isInside(0, 0);
        i.union(i);
        i.intersection(i);
    }
}