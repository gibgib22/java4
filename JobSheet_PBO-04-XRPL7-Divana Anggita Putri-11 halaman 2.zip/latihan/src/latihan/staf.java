
package latihan;

public class staf extends pegawai{
    private static final int gajiStaf=50000;
    private static final int bonus=10000;
    
    public int gaji(){
        return gajiStaf;
    }
    public int bonus(){
        return bonus;
    }
}
