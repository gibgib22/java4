package pbo2;

/**
 *
 * @author DIVANA
 */
public class encapsiswa {
    private String nama;
    private String addres;
    private int absen;
    
    public int getAbsen(){
        return absen;
    }
    
    public String getNama(){
        return nama;
    }
    
    public String getAddres(){
        return addres;
    }
    
    public void setAge(int newAbsen){
        absen = newAbsen;
    }
    
    public void setNama(String newNama){
        nama = newNama;
    }
    
    public void getAddress(String newAddress){
        addres = newAddress;}
}
