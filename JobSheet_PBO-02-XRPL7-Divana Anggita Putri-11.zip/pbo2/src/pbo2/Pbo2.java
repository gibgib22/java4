package pbo2;

/**
 *
 * @author DIVANA
 */
public class Pbo2 {
    public int penumpang;
    public int maxpenumpang;
    
    public void cetak(){
        System.out.println("penumpang bus sekarang adalah " +penumpang);
        System.out.println("penumpang maksimum adalah " +maxpenumpang);
    }
}